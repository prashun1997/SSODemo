
Office.onReady((info)=> {
     if(info.host === Office.HostType.Excel)
     {
         var idtoken;
         var graphtoken;
         document.getElementById("get_idToken").addEventListener("click",function(){
             idtoken = getidToken();
             idtoken.then(token =>
                {
                    document.getElementById("get_graphToken").addEventListener("click",function(){
                        graphtoken=getgraphToken(token);
                    })
                });
         })
        
     }
})

async function getgraphToken(token)
{
    try
    {
    let response = await $.ajax({type:'GET',
        url:'auth',
    headers:{"Authorization": "Bearer "+token},
    cache:false});
    document.getElementById("graph_token").innerText = "Graph token=" + response.access_token;
    return response;
    }
    catch(error)
    {
        document.getElementById("graph_token").innerText = "Getting error"; 
    }

}
async function getidToken()
{
    try{
        let token =await OfficeRuntime.auth.getAccessToken({allowSignInPrompt:true,allowConsentPrompt:true,forMSGraphAccessToken:true});
        document.getElementById("id_token").innerText= "ID Token = "+token;
        return token;
    }
    catch(error)
    {
        document.getElementById("id_token").innerText= "Error received:"+error.code;
        
    }
}