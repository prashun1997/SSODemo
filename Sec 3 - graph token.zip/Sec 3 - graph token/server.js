const express= require("express")
const https = require("https")
const fs= require("fs");
const path =require("path")
var fetch = require("node-fetch")
var formurlencoded = require('form-urlencoded');

const cert = fs.readFileSync("C:/Users/prdalmia/.office-addin-dev-certs/localhost.crt");
const key =fs.readFileSync("C:/Users/prdalmia/.office-addin-dev-certs/localhost.key");
const app=express();

const server = https.createServer({key:key, cert:cert},app);

app.use(express.static(__dirname+'/public'));

app.get("/",(req,resp) => {resp.sendFile(__dirname+"index.html")});

app.get("/auth", async(req,res)=>
{
    const authorization = req.get("Authorization");

    if(authorization==null)
    {
        
        console.log("No auth header was found");
       
    }
    else
    {
        const[schema, jwt] = authorization.split(' ');
        const formParams = {
            client_id : "0943571c-5a92-4fb9-bf89-701fb844e403",
            client_secret : "E_-Ast_8w-XCuJr8O25K9_Ir889sUk4nr1",
            grant_type : 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            assertion: jwt,
            requested_token_use : "on_behalf_of",
            scope: ['Files.Read.All'].join(' ')
        };
        const stsdomain = 'https://login.microsoftonline.com';
        const tenant = 'organizations';
        const tokenurl = 'oauth2/v2.0/token';

        try{
            const tokenResponse = await fetch(`${stsdomain}/${tenant}/${tokenurl}`,{
                method : 'POST',
                body : formurlencoded(formParams),
                headers: {
                        'Accept' : 'application/json',
                        'Content-Type' : 'application/x-www-form-urlencoded'
                }

            });
            console.log("response="+tokenResponse);
            const json = await tokenResponse.json();
            
            res.send(json);
        }
        catch(error){
            console.log("Error coming"+error);
            res.status(500).send(error);
        }
    }
});

server.listen("3001", ()=>{console.log("Listening on port 3001")});

