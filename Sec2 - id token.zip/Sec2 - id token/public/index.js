
Office.onReady((info)=> {
     if(info.host === Office.HostType.Excel)
     {
         var idtoken;
         document.getElementById("get_idToken").addEventListener("click",function(){
             idtoken = getidToken();
         })
     }
})

async function getidToken()
{
    try{
        let token =await OfficeRuntime.auth.getAccessToken({allowSignInPrompt:true,allowConsentPrompt:true,forMSGraphAccessToken:true});
        document.getElementById("id_token").innerText= "ID Token = "+token;
        return token;
    }
    catch(error)
    {
        document.getElementById("id_token").innerText= "Error received:"+error.code;
        
    }
}